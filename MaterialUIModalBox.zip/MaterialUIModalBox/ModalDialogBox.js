import React from 'react';

// material ui package and modules
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Modal from '@material-ui/core/Modal';

function rand() {
    return(Math.round(Math.random() * 20) - 10);
  }
  
  function getModalStyle() {
    const top = 50 + rand();
    const left = 50 + rand();
  
    return {
      top: `${top}%`, 
      left: `${left}%`, 
      transform: `translate(-${top}%, -${left}%)` 
    }
  }
  
  const useStyles = makeStyles(theme => ({
    modal: {
      display: 'flex', 
      alignItems: 'center', 
      justifyContent: 'center'
    }, 
    paper: {
      position: 'absolute', 
      width: '450px', 
      backgroundColor: theme.palette.background.paper, 
      boxShadow: theme.shadows[5], 
      padding: theme.spacing(2, 4, 3)
    }
}));

export default function ModalDialogBox() {
    const classes = useStyles();
    const [modalStyle] = React.useState(getModalStyle);
    const [open, setOpen] = React.useState(false);

    const handleOpen = () => {
        setOpen(true);
    }


    const handleClose = () => {
        setOpen(false);
    }

    return(
        <div>
            <Button variant="container" color="primary" onClick={handleOpen}> click button </Button>

            <Modal
                aria-labelledby="modal-title" 
                aria-describedby="modal-description" 
                open={open} 
                onClose={handleClose}
            >
                <div style={modalStyle} className={classes.paper}>
                    <h4> modal dial box </h4>
                    
                    <p>Over the years of developing websites for clients, I’ve learned that the age-old adage, “If you want it done right, you gotta do it yourself,” can be a two-way street.</p>

                    <p>Of course, there are companies out there that have great web writers internally, but most don’t. And the thought of a company turning a great website content strategy (that we slaved over) into an ineffective “brochure site” gives me heartburn. But sometimes you have to pick your battles.</p>
                </div>
            </Modal>
        </div>
    );

}