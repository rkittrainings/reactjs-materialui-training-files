import React from 'react';

import Footer from '../Footer/Footer';
import Header from '../Header/Header';
import LeftPanel from '../LeftPanel/LeftPanel';
import RightPanel from '../RightPanel/RightPanel';

import ModalDialogBox from './ModalDialogBox';

class MaterialUIModalBox extends React.Component {
  
  render() {
    return(
      <div className="container">
        <div className="row">
          <div className="col-sm-12">
            <Header />
          </div>
        </div>

        <div className="row">
          <div className="col-sm-3">
            <LeftPanel />
          </div>
          <div className="col-sm-6">
            <div className="container">
              <div className="row">
                  <div className="col-sm-12">
                      <h4>Material UI Modal Box</h4>

                      <ModalDialogBox />
                      
                  </div>
                </div>
            </div>
          </div>
          <div className="col-sm-3">
            <RightPanel />
          </div>
        </div>

        <div className="row">
          <div className="col-sm-12">
            <Footer />
          </div>
        </div>
      </div>
    )
  }
}

export default MaterialUIModalBox;